/*
 * voa_comm.c
 *
 *  Created on: Jan 19, 2023
 *      Author: tcole
 */

#include "voa_comm.h"
/* Private includes ----------------------------------------------------------*/


/* Private typedef -----------------------------------------------------------*/
struct data{
	uint8_t send[12];
	uint8_t receive[12];
	uint8_t size;
} i2c_data;

/* Private define ------------------------------------------------------------*/
#define BUFFER_LENGTH			12

/* Private macro -------------------------------------------------------------*/


/* Private variables ---------------------------------------------------------*/
I2C_HandleTypeDef hi2c1;
uint8_t setting_voa_check;
uint8_t touchscreen_input_enabled;

enum voa_setting{
	set,
	flagged,
	done,
	aardvark_started,
	aardvark_done,
};

enum touchscreen_enable{
	enable,
	disable,
};

/* Private function prototypes -----------------------------------------------*/
static void MX_I2C1_Init(void);
void i2c_receive(uint8_t address, uint8_t *data, uint8_t size);
void i2c_transmit(uint8_t address, uint8_t *send_data, uint8_t size);
void reset_buffer(void);


/**
  * @brief I2C1 Initialization Function
  * @param None
  * @retval None
  */
static void MX_I2C1_Init(void)
{

  /* USER CODE BEGIN I2C1_Init 0 */

  /* USER CODE END I2C1_Init 0 */

  /* USER CODE BEGIN I2C1_Init 1 */

  /* USER CODE END I2C1_Init 1 */
  hi2c1.Instance = I2C1;
  hi2c1.Init.ClockSpeed = 10000;
  hi2c1.Init.DutyCycle = I2C_DUTYCYCLE_2;
  hi2c1.Init.OwnAddress1 = 0;
  hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
  hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
  hi2c1.Init.OwnAddress2 = 0;
  hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
  hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
  if (HAL_I2C_Init(&hi2c1) != HAL_OK)
  {
    Error_Handler();
  }
  /* USER CODE BEGIN I2C1_Init 2 */

  /* USER CODE END I2C1_Init 2 */

}

void voa_comm_init(void){
	MX_I2C1_Init();
	i2c_data.size = 0;
	reset_buffer();
	setting_voa_check = done;
}

void reset_buffer(void){
	for(int i=0; i<BUFFER_LENGTH; i++){
	  i2c_data.send[i] = 0;
	  i2c_data.receive[i] = 0;
	}
}

void init_voa(void) {
  //send and receive data has depth of 12 (for multiple bytes?)

  //Construct send package (write)
  //to_slave holds return of the master transmit
  i2c_data.send[0] = 0x8D;
  i2c_data.size = 1;
  i2c_transmit(VOA_1_ADDR, i2c_data.send, i2c_data.size);

  //Construct receive package (read)
  //to_slave holds return of the master transmit
  i2c_data.size = 3;
  i2c_receive(VOA_1_ADDR, i2c_data.receive, i2c_data.size);

  i2c_data.send[0] = 0;

  //Construct send package (write)
  //to_slave holds return of the master transmit
  i2c_data.send[0] = 0x80;
  i2c_data.send[1] = 0xFF;
  i2c_data.send[2] = 0x05;
  i2c_data.size = 3;

  i2c_transmit(VOA_1_ADDR, i2c_data.send, i2c_data.size);

  reset_buffer();
  set_attenuation(5);
}

void voa_busy(void){
	if(setting_voa_check == set){
		setting_voa_check = flagged;
	} else if (setting_voa_check == flagged){
		setting_voa_check = done;
	} else if(setting_voa_check == done){
		setting_voa_check = aardvark_started;
	} else {
		setting_voa_check = aardvark_done;
		aardvard_callback();
	}
}

void aardvard_callback(void){
	//disable all i2c and cancel all comm
	float atten = query_attenuation();
	touchscreen_input_enabled = disable;

	//send something to touchscreen to disable use

	//wait til line not busy, then query VOA

}

void set_attenuation(float dB){
	reset_buffer();
	uint32_t value = (int)(dB * 100);
	if(value & (0xFFFF0000)){
		//out of range, tell touchscreen
		Error_Handler();
	}
	i2c_data.send[0] = 0x80;
	i2c_data.send[1] = (value & (0xFF00)) >> 8;
	i2c_data.send[2] = value & (0xFF);
	i2c_data.size = 3;
	i2c_transmit(VOA_1_ADDR, i2c_data.send, i2c_data.size);
	return;
}

float query_attenuation(void){
	float dB;
	reset_buffer();
	i2c_data.send[0] = 0x81;
	i2c_data.size = 1;
	i2c_transmit(VOA_1_ADDR, i2c_data.send, i2c_data.size);
	i2c_data.size = 2;
	i2c_receive(VOA_1_ADDR, i2c_data.receive, i2c_data.size);
	dB = (float)((i2c_data.receive[1] << 8) | i2c_data.receive[0]);
	dB = dB / 100.0;
	return dB;
}

void device_id(void){
	return;
}

void i2c_transmit(uint8_t address, uint8_t *send_data, uint8_t size){
	HAL_StatusTypeDef to_slave;
	char error;
//	HAL_NVIC_DisableIRQ(EXTI2_IRQn);
	setting_voa_check = set;
	to_slave = HAL_I2C_Master_Transmit(&hi2c1,address,send_data,size,HAL_MAX_DELAY);
//	HAL_NVIC_EnableIRQ(EXTI2_IRQn);
	//check proper write
	if(to_slave != HAL_OK) {
		//throw error
//		Error_Handler();
		error = 1;
	}
}

void i2c_receive(uint8_t address, uint8_t *data, uint8_t size){
	HAL_StatusTypeDef from_slave;
	char error;
//	HAL_NVIC_DisableIRQ(EXTI2_IRQn);
	from_slave = HAL_I2C_Master_Receive(&hi2c1,address,data,size,HAL_MAX_DELAY);
//	HAL_NVIC_EnableIRQ(EXTI2_IRQn);
	//compare expected receive results
	if(from_slave != HAL_OK) {
		//throw error
//		Error_Handler();
		error = 1;
	}
}
