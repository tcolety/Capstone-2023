/*
 * UART.h
 *
 *  Created on: Feb 16, 2023
 *      Author: tcole
 */

#ifndef SRC_UART_H_
#define SRC_UART_H_

#include "stm32f1xx_hal.h"

void UART_init(void);
void touchscreen_update(char * buffer);

#endif /* SRC_UART_H_ */
