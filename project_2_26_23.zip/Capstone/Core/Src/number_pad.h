/*
 * number_pad.h
 *
 *  Created on: Feb 16, 2023
 *      Author: tcole
 */

#ifndef SRC_NUMBER_PAD_H_
#define SRC_NUMBER_PAD_H_

/* Private includes ----------------------------------------------------------*/
#include "stm32f1xx_hal.h"

/* Exported types ------------------------------------------------------------*/

/* Exported constants --------------------------------------------------------*/

/* Exported macro ------------------------------------------------------------*/

/* Exported functions prototypes ---------------------------------------------*/
void number_pad_callback(void);

/* Private defines -----------------------------------------------------------*/


#endif /* SRC_NUMBER_PAD_H_ */
