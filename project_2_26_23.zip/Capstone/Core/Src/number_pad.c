/*
 * number_pad.c
 *
 *  Created on: Feb 16, 2023
 *      Author: tcole
 */

/* Private includes ----------------------------------------------------------*/
#include "number_pad.h"

/* Private typedef -----------------------------------------------------------*/


/* Private define ------------------------------------------------------------*/


/* Private macro -------------------------------------------------------------*/


/* Private variables ---------------------------------------------------------*/
struct buffer_format{
	char buff[12];
	uint8_t recent;
	uint8_t index;
}np_buffer;

/* Private function prototypes -----------------------------------------------*/


/* Private user code ---------------------------------------------------------*/


/* Private user code ---------------------------------------------------------*/

/**
  * @brief Intreprets number that's been pressed
  * @param None
  * @retval None
  */
void number_pad_callback(void){
	char num;

	//interpret button pressed

	//if statement to decide which function to call:

		//if number, add number to buffer
		// add_to_buffer();

		//if delete button, delete number
		// delete_char();

	//updates the touchscreen
	touchscreen_update(np_buffer.buff);

		// if done button, send number to voa
		// set_attenuation(buffer);
}


